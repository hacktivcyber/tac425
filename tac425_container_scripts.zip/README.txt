TAC425 container start/stop scripts

Each start script prints the exact command before running it.
The Zero Health scripts auto-select docker-compose if available, otherwise docker compose.
